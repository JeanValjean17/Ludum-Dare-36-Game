﻿using UnityEngine;
using System.Collections;

public class ControllerPhsyicsVolume2D : MonoBehaviour
{
	public ControllerParameters2D Parameters;
}